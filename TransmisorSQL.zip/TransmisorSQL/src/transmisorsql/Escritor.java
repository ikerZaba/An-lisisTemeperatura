/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transmisorsql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.chrono.ChronoLocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 *
 * @author alumno
 */
public class Escritor {

    static void insertarEstaciones(List<Estacion> estaciones,Connection con) throws SQLException {
        PreparedStatement stmt2 = con.prepareStatement("INSERT INTO Lugar VALUES (?,?)");
        for (Estacion estacion : estaciones) {
            stmt2.setString(1, estacion.getNombreEstacion().replace("%20"," "));
            stmt2.setString(2, estacion.getComarca());
            
            stmt2.executeUpdate();
        }
        
    }
    

    static void intertarDatosEnSQL(List<Lectura> datos,Connection con) throws SQLException {

        for (Lectura dato : datos) {

            PreparedStatement stmt = con.prepareStatement("INSERT INTO Hechos VALUES (?,?,?,?)");
            
            stmt.setString(1, dato.getHecho());
            stmt.setString(2, dato.getNombreEstacion().replace("%20"," ").replace("%C3%A1","á").replace("%C3%A9","é").replace("%C3%AD","í").replace("%C3%B3", "ó").replace("%C3%B1", "ñ"));
            stmt.setDate(3, new java.sql.Date(dato.getFecha().getTime()));//(date.get(Calendar.YEAR), date.get(Calendar.MONTH), date.get(Calendar.DAY_OF_MONTH)));
            stmt.setDouble(4, dato.getTempMedia());

            stmt.executeUpdate();
            
            
        }

    }

    static void insertarFechas(Connection con) throws SQLException, ParseException {
        PreparedStatement stmt3 = con.prepareStatement("INSERT INTO Fecha VALUES (?,?,?,?,?)");
        Date startDate = new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2004");
        Date endDate = new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2020");
        Calendar start = Calendar.getInstance();
        start.setTime(startDate);
        Calendar end = Calendar.getInstance();
        end.setTime(endDate);

        for (Date date = start.getTime(); start.before(end); start.add(Calendar.DATE, 1), date = start.getTime()) {
            
            stmt3.setDate(1, new java.sql.Date(date.getTime()));//(start.get(Calendar.YEAR), start.get(Calendar.MONTH), start.get(Calendar.DAY_OF_MONTH)));
            stmt3.setInt(2, start.get(Calendar.DAY_OF_MONTH));
            stmt3.setInt(3, start.get(Calendar.MONTH));
            stmt3.setInt(4, start.get(Calendar.YEAR));
            stmt3.setInt(5, start.get(Calendar.WEEK_OF_YEAR));

            stmt3.executeUpdate();
        }
    }

}

   
            
           
