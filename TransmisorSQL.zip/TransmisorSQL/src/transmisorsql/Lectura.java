/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transmisorsql;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alumno
 */
public class Lectura {
    String hecho;
    Date fecha;
    double tempMedia;
    String nombreEstacion;

    public Lectura(String fechaHora, double tempMedia,String nombreEstacion,String provincia) throws ParseException {
        //dividir la fecha 
        //Formato: dd/mm/aa 00:00:00
        
        this.hecho = fechaHora.replace("00:00:00","")+" "+nombreEstacion.replace("%20"," ");
        this.fecha =  new SimpleDateFormat("dd/MM/yyyy").parse(fechaHora.substring(0,10));
        this.tempMedia = tempMedia;
        this.nombreEstacion = nombreEstacion;
        System.out.println(this.hecho+": "+this.tempMedia+"ºC");
}
    
    
    public static List<Lectura> leerDatosEstacionCSV(String file,String nombreEstacion,String provincia) throws NumberFormatException, ParseException, FileNotFoundException {
        List<Lectura> datos = new ArrayList<>();
        try (BufferedReader br
                = new BufferedReader(new FileReader(file))) {

            for (String line; (line = br.readLine()) != null;) {
                line = line.replace(", ", "").replace("  ", " ");
                String[] parts = line.split(";");
                //si es la primera entrada: comprobar en que columna esta la temp media
                //-> si no esta, la temp media de ese año no se calcula 
                //(ya que los datos no son fieles con la realidad y el numero de
                //años sin temperatura media son muy aislados)
                try {
                    if (parts.length == 14||parts.length == 11) {
                        Lectura a = new Lectura(parts[0], Double.parseDouble(parts[2]),nombreEstacion,provincia);
                        datos.add(a);
                    }
                } catch (NumberFormatException ne) {

                }

            }

        } catch (IOException ex) {
            Logger.getLogger(TransmisorSQL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datos;
    }

    public String getHecho() {
        return hecho;
    }

    public Date getFecha() {
        return fecha;
    }


    public double getTempMedia() {
        return tempMedia;
    }

    public String getNombreEstacion() {
        return nombreEstacion;
    }

}
