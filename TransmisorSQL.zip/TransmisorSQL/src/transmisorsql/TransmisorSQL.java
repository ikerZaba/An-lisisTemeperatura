/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transmisorsql;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.chrono.ChronoLocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 *
 * @author alumno
 */
public class TransmisorSQL {
    
    
    
    public static void main(String[] args) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException, NumberFormatException, ParseException, FileNotFoundException {

        //Conexión a la BBDD
        Connection con = null;
        String sURL = "jdbc:mysql://172.18.73.62:3306/aaee_36";
        String sDriver = "com.mysql.jdbc.Driver";
        Class.forName(sDriver);
        con = DriverManager.getConnection(sURL, "aaee_36", "aaee_36");
        
        System.out.println("Conectado");
        //Leer las estaciones
        String estacionesCSV = "Estaciones_Navarra.csv";
        List<Estacion> estaciones = Estacion.leerEstacionesCSV(estacionesCSV);
        //Escritor.insertarEstaciones(estaciones,con);
        
        //Crear fechas
        Escritor.insertarFechas(con);
        
        for (Estacion est : estaciones) {
            //Leer los datos de cada año
            System.out.println(est.getNombreEstacion());
            for (int año = 2004; año < 2020; año++) {
                
                TransmisorSQL.descargarDatos(año, est.getNumeroEstacion(), est.getNombreEstacion());

                String datosEstacionCSV = "/home/alumno/Escritorio/datos¿_?.csv";
                datosEstacionCSV = datosEstacionCSV.replace("¿", String.valueOf(año));
                
                String nombreOG = est.getNombreEstacion();
                
                //Corrección para leer los datos de las estaciones de tipo MAPA, cuyo formato cambia en los años 2019-20
                if (est.getNombreEstacion().contains("MAPA") && año >= 2019) {
                    est.setNombreEstacion(est.getNombreEstacion().replace("MAPAma", "MAPA"));
                }
                //Quitamos las tildes y las 'ñ'
                est.setNombreEstacion(est.getNombreEstacion().replace("á","%C3%A1").replace("é","%C3%A9").replace("í","%C3%AD").replace("ó", "%C3%B3").replace("ñ", "%C3%B1"));
                
                datosEstacionCSV = datosEstacionCSV.replace("?", est.getNombreEstacion().replace("%20","").toLowerCase());
                
                
                List<Lectura> datos = Lectura.leerDatosEstacionCSV(datosEstacionCSV,nombreOG,est.getComarca());

                Escritor.intertarDatosEnSQL(datos,con);
            } 
        }

    }
    
    public static void descargarDatos(int año,int num_estacion,String nombre_estacion) {
        
        String url = "http://meteo.navarra.es/_data/datos_estaciones/estacion_!/datos%20diarios/$_?.csv";        
        url = url.replace("!",String.valueOf(num_estacion));
        //A partir de 2019 la estaciones tipo MAPA tienen de nombre solo MAPA no MAPAMA
        if(nombre_estacion.contains("MAPA")&&año>=2019){
            nombre_estacion = nombre_estacion.replace("MAPAma","MAPA");
        }
        nombre_estacion = nombre_estacion.replace("á","%C3%A1").replace("é","%C3%A9").replace("í","%C3%AD").replace("ó", "%C3%B3").replace("ñ","%C3%B1");
        
        url = url.replace("$",nombre_estacion.toLowerCase());
        url = url.replace("?",String.valueOf(año));
        String file = "/home/alumno/Escritorio/datos¿_?.csv";//El nombre del fichero al guardarlo
        
        file = file.replace("¿",String.valueOf(año));
        file = file.replace("?",nombre_estacion.replace("%20","").toLowerCase());
        try (BufferedInputStream inputStream = new BufferedInputStream(new URL(url).openStream());
            FileOutputStream fileOS = new FileOutputStream(file)) {
            byte data[] = new byte[1024];
            int byteContent;
            while ((byteContent = inputStream.read(data, 0, 1024)) != -1) {
                fileOS.write(data, 0, byteContent);
            }
        } catch (IOException e) {
            // handles IO exceptions
        }
    }

}
