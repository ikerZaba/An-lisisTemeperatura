/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transmisorsql;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alumno
 */
class Estacion {
    String nombreEstacion;
    String comarca;
    int numeroEstacion;

    public Estacion(String nombreEstacion, String provincia, int numeroEstacion) {
        this.nombreEstacion = nombreEstacion;
        this.comarca = provincia;
        this.numeroEstacion = numeroEstacion;
    }
    
    
    static List<Estacion> leerEstacionesCSV(String estacionesCSV) {
        List<Estacion> datos = new ArrayList<>();
        try (BufferedReader br
                = new BufferedReader(new FileReader(estacionesCSV))) {

            for (String line; (line = br.readLine()) != null;) {
                String[] parts = line.split(",");
                //si es la primera entrada: comprobar en que columna esta la temp media
                //-> si no esta, la temp media de ese año no se calcula 
                //(ya que los datos no son fieles con la realidad y el numero de
                //años sin temperatura media son muy aislados)
                try {
                    if (parts.length == 3) {
                        Estacion a = new Estacion(parts[0], parts[1], Integer.parseInt(parts[2]));
                        datos.add(a);
                    }
                } catch (NumberFormatException ne) {

                }

            }

        } catch (IOException ex) {
            Logger.getLogger(TransmisorSQL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return datos;
    }

    public String getNombreEstacion() {
        return nombreEstacion;
    }

    public String getComarca() {
        return comarca;
    }

    public int getNumeroEstacion() {
        return numeroEstacion;
    }

    public void setNombreEstacion(String nombreEstacion) {
        this.nombreEstacion = nombreEstacion;
    }

    
    
}
